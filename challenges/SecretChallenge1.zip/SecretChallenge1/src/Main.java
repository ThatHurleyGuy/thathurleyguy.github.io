public class Main {
    public static void main(String [] args) {
        Image inputImage = new Image("odds_and_evens.png");
        Image outputImage = new Image(inputImage.getWidth(), inputImage.getHeight());

        System.out.println("Picture is " + inputImage.getWidth() + " pixels wide");
        System.out.println("Picture is " + inputImage.getHeight() + " pixels tall");

        for(int i=0; i<inputImage.getWidth(); i++) {
            // Copy pixel from input image
            Pixel inputPixel = inputImage.getPixel(i, i);
            outputImage.setPixel(i, i, inputPixel.red, inputPixel.green, inputPixel.blue);
        }

        // Write the output image
        outputImage.write("output.png");
    }
}
