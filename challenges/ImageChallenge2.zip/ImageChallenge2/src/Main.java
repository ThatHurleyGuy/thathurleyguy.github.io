public class Main {
    public static void main(String [] args) {
        Image image1 = new Image("scrambled1.png");
        Image image2 = new Image("scrambled2.png");
        System.out.println(image1.getPixel(0,0));
        System.out.println(image2.getPixel(0,0));
    }
}
